import Link from "next/link"
import Image from "next/image"
import { Search, ShoppingCart, User } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import ProductCard from "@/components/product-card"

export default function Home() {
  // Sample featured products data
  const featuredProducts = [
    {
      id: 1,
      name: "Minimalist Sneakers",
      price: 129.99,
      image: "/placeholder.svg?height=400&width=400",
    },
    {
      id: 2,
      name: "Classic Tee",
      price: 39.99,
      image: "/placeholder.svg?height=400&width=400",
    },
    {
      id: 3,
      name: "Urban Backpack",
      price: 89.99,
      image: "/placeholder.svg?height=400&width=400",
    },
    {
      id: 4,
      name: "Wireless Earbuds",
      price: 149.99,
      image: "/placeholder.svg?height=400&width=400",
    },
    {
      id: 5,
      name: "Smart Watch",
      price: 199.99,
      image: "/placeholder.svg?height=400&width=400",
    },
    {
      id: 6,
      name: "Slim Wallet",
      price: 49.99,
      image: "/placeholder.svg?height=400&width=400",
    },
  ]

  return (
    <div className="flex min-h-screen flex-col">
      {/* Header */}
      <header className="sticky top-0 z-50 w-full border-b bg-white/80 backdrop-blur-md">
        <div className="container mx-auto flex h-16 items-center justify-between px-4">
          {/* Logo */}
          <Link href="/" className="flex items-center gap-2 font-bold text-xl">
            <Image src="/placeholder.svg?height=32&width=32" alt="Logo" width={32} height={32} />
            <span className="hidden sm:inline">MINIMAL</span>
          </Link>

          {/* Navigation - Desktop */}
          <nav className="hidden md:flex items-center space-x-6">
            <Link href="/" className="text-sm font-medium transition-colors hover:text-black/70">
              Home
            </Link>
            <Link href="/products" className="text-sm font-medium transition-colors hover:text-black/70">
              Products
            </Link>
            <Link href="/about" className="text-sm font-medium transition-colors hover:text-black/70">
              About
            </Link>
            <Link href="/contact" className="text-sm font-medium transition-colors hover:text-black/70">
              Contact
            </Link>
          </nav>

          {/* Search Bar */}
          <div className="hidden md:flex relative w-full max-w-sm mx-4">
            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-gray-500" />
            <Input
              type="search"
              placeholder="Search products..."
              className="w-full rounded-md border pl-8 pr-4 py-2 focus:outline-none focus:ring-2 focus:ring-black/5"
            />
          </div>

          {/* Icons */}
          <div className="flex items-center space-x-4">
            <Button variant="ghost" size="icon" className="relative" aria-label="Search" asChild>
              <Link href="/search" className="md:hidden">
                <Search className="h-5 w-5" />
              </Link>
            </Button>
            <Button variant="ghost" size="icon" className="relative" aria-label="Cart" asChild>
              <Link href="/cart">
                <ShoppingCart className="h-5 w-5" />
                <span className="absolute right-0 top-0 flex h-4 w-4 items-center justify-center rounded-full bg-black text-[10px] font-medium text-white">
                  3
                </span>
              </Link>
            </Button>
            <Button variant="ghost" size="icon" aria-label="Account" asChild>
              <Link href="/account">
                <User className="h-5 w-5" />
              </Link>
            </Button>
            <Button variant="outline" size="sm" className="hidden md:flex" asChild>
              <Link href="/account/login">Sign In</Link>
            </Button>
          </div>
        </div>
      </header>

      <main className="flex-1">
        {/* Hero Section */}
        <section className="relative bg-gray-50">
          <div className="container mx-auto px-4 py-16 md:py-24">
            <div className="grid gap-8 md:grid-cols-2 md:gap-12 items-center">
              <div className="space-y-4">
                <h1 className="text-4xl font-bold tracking-tight sm:text-5xl md:text-6xl">Discover Your Style</h1>
                <p className="max-w-[600px] text-gray-500 md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
                  Curated collections for the modern lifestyle. Minimalist designs with maximum impact.
                </p>
                <div className="flex flex-col gap-2 min-[400px]:flex-row">
                  <Button size="lg" asChild>
                    <Link href="/products">Shop Now</Link>
                  </Button>
                  <Button variant="outline" size="lg" asChild>
                    <Link href="/collections">View Collections</Link>
                  </Button>
                </div>
              </div>
              <div className="relative aspect-video md:aspect-square overflow-hidden rounded-xl">
                <Image
                  src="/placeholder.svg?height=600&width=600"
                  alt="Featured collection"
                  fill
                  className="object-cover"
                  priority
                />
              </div>
            </div>
          </div>
        </section>

        {/* Featured Products */}
        <section className="container mx-auto px-4 py-12 md:py-16">
          <div className="flex flex-col md:flex-row justify-between items-baseline mb-8">
            <h2 className="text-2xl font-bold tracking-tight sm:text-3xl md:text-4xl">Featured Products</h2>
            <Link href="/products" className="text-sm font-medium hover:underline mt-2 md:mt-0">
              View all products →
            </Link>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6 lg:gap-8">
            {featuredProducts.map((product) => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
        </section>

        {/* Newsletter */}
        <section className="bg-gray-50 py-12 md:py-16">
          <div className="container mx-auto px-4 text-center">
            <h2 className="text-2xl font-bold tracking-tight sm:text-3xl mb-4">Join Our Newsletter</h2>
            <p className="max-w-md mx-auto text-gray-500 mb-6">
              Stay updated with the latest products, exclusive offers, and style tips.
            </p>
            <div className="flex flex-col sm:flex-row gap-2 max-w-md mx-auto">
              <Input type="email" placeholder="Enter your email" className="flex-1" />
              <Button>Subscribe</Button>
            </div>
          </div>
        </section>
      </main>

      {/* Footer */}
      <footer className="bg-gray-900 text-gray-300">
        <div className="container mx-auto px-4 py-12">
          <div className="grid grid-cols-1 gap-8 sm:grid-cols-2 md:grid-cols-4">
            <div>
              <h3 className="mb-4 text-lg font-medium text-white">Shop</h3>
              <ul className="space-y-2">
                <li>
                  <Link href="/products" className="hover:text-white transition-colors">
                    All Products
                  </Link>
                </li>
                <li>
                  <Link href="/collections" className="hover:text-white transition-colors">
                    Collections
                  </Link>
                </li>
                <li>
                  <Link href="/featured" className="hover:text-white transition-colors">
                    Featured
                  </Link>
                </li>
                <li>
                  <Link href="/new-arrivals" className="hover:text-white transition-colors">
                    New Arrivals
                  </Link>
                </li>
              </ul>
            </div>
            <div>
              <h3 className="mb-4 text-lg font-medium text-white">Support</h3>
              <ul className="space-y-2">
                <li>
                  <Link href="/faq" className="hover:text-white transition-colors">
                    FAQ
                  </Link>
                </li>
                <li>
                  <Link href="/shipping" className="hover:text-white transition-colors">
                    Shipping & Returns
                  </Link>
                </li>
                <li>
                  <Link href="/contact" className="hover:text-white transition-colors">
                    Contact Us
                  </Link>
                </li>
              </ul>
            </div>
            <div>
              <h3 className="mb-4 text-lg font-medium text-white">Company</h3>
              <ul className="space-y-2">
                <li>
                  <Link href="/about" className="hover:text-white transition-colors">
                    About Us
                  </Link>
                </li>
                <li>
                  <Link href="/privacy" className="hover:text-white transition-colors">
                    Privacy Policy
                  </Link>
                </li>
                <li>
                  <Link href="/terms" className="hover:text-white transition-colors">
                    Terms of Use
                  </Link>
                </li>
              </ul>
            </div>
            <div>
              <h3 className="mb-4 text-lg font-medium text-white">Contact</h3>
              <ul className="space-y-2">
                <li>support@minimal.com</li>
                <li>+1 (555) 123-4567</li>
                <li className="flex space-x-4 pt-2">
                  <Link href="https://instagram.com" className="hover:text-white transition-colors">
                    Instagram
                  </Link>
                  <Link href="https://twitter.com" className="hover:text-white transition-colors">
                    Twitter
                  </Link>
                  <Link href="https://facebook.com" className="hover:text-white transition-colors">
                    Facebook
                  </Link>
                </li>
              </ul>
            </div>
          </div>
          <div className="mt-8 border-t border-gray-800 pt-8 text-center text-sm">
            <p>© {new Date().getFullYear()} MINIMAL. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  )
}
